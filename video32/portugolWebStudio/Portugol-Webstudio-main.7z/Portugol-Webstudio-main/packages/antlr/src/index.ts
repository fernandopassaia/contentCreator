export * from "./PortugolErrorListener.js";
export * from "./PortugolLexer.js";
export * from "./PortugolListener.js";
export * from "./PortugolParser.js";
export * from "./PortugolVisitor.js";
