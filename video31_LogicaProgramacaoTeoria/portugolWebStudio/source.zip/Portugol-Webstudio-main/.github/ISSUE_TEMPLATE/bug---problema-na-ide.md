---
name: Bug / Problema na IDE
about: Reportar problemas encontrados na interface ou na execução de código
title: ''
labels: bug
assignees: ''

---

## Descrição do Problema:

Digite abaixo (entre os acentos) o que está acontecendo.

```

```

## Código:

Cole abaixo o seu código que está dando problema, caso seja problema com código.

```portugol
programa {

}
```
