# `@portugol-webstudio/ide`

Este pacote contém a IDE do Portugol Webstudio, um ambiente de desenvolvimento integrado para a linguagem Portugol desenvolvido com o framework [Angular](https://angular.io/), [Angular Material](https://material.angular.io/) e [Monaco Editor](https://microsoft.github.io/monaco-editor/).
