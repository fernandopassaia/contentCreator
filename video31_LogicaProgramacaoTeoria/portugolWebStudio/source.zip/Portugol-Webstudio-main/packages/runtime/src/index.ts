export * from "./PortugolJs.js";
export { runtime as PortugolJsRuntime } from "./runtime/index.js";
